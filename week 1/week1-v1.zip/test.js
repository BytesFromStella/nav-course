function login(username, password) {
    if (username == "test1", password == "test2") {
        if (password == "test2") {
            return true;
        }
    }
    return false;
}

login("dette er et brukernavn", "dette er et passord");